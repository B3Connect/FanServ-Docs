//
//  AdServer.h
//  AdServerFramework
//
//  Created by Lion User on 15/10/2012.
//  Copyright (c) 2012 B3Connect. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>


@protocol FanServerAdServerAdsDelegate <NSObject>
@optional
- (void) fanServerBannerDidAppear;
- (void) fanServerBannerDidClose;
- (void) fanServerInterstitialDidAppear;
- (void) fanServerInterstitialDidClose;
- (void) fanServerAdDidFail;
- (void) fanServerPopupDidAppear;
- (void) fanServerPopupDidClose;
- (void) fanServerRequestDidFail;
- (void) fanServerAdTapped;
- (void) fanServerDidBackFromAdView;
@end

@protocol FanServerAdServerDelegate <NSObject>
@optional
- (void) fanServerAdServerDelegateAdClosed;
- (void) fanServerCloseLoading;
- (void) fanServerShowLoading;

@end

typedef enum{
    FanServerAdAnimationFromLeft = 1,
    FanServerAdAnimationFromRight,
    FanServerAdAnimationFromTop,
    FanServerAdAnimationFromBottom,
    FanServerAdAnimationFade
} FanServerAdAnimationOptions;

typedef enum{
    FanServerAdTypeInterstitial = 1,
    FanServerAdTypeBanner,
    FanServerAdTypePopup
} FanServerAdType;

typedef enum{
    FanServerDeviceTypeMobile = 1,
    FanServerDeviceTypeTablet,
    FanServerDeviceTypeWeb
} FanServerDeviceType;

typedef enum{
    FanServerAdFemale = 1,
    FanServerAdMale,
    FanServerAdAny
} FanServerAdGender;

typedef enum{
    FanServerProd = 0,
    FanServerQa
} FanServerAddress;

@interface FanServer : NSObject

+ (void) setAdsDelegate:(id<FanServerAdServerAdsDelegate>)delegate;
+ (void) setWindow: (UIWindow *) w;
+ (void) setIsAdVisible: (BOOL) isVisible;
+ (void) setShowAdOnLoad:(BOOL)c;
+ (void) setRotateBannerInLandscape: (BOOL) rotate;
+ (void) setAnimationStyle: (FanServerAdAnimationOptions) style;
+ (void) setShowAfterLoading: (BOOL) showAd;
+ (void) setScreenName:(NSString *)name;
+ (void) setAudioPlaying:(BOOL) choice;
+ (void) setProjectName:(NSString *)name;
+ (void) setShouldCloseBanner:(BOOL)choice;
+ (void) setAdType: (FanServerAdType)type size: (NSString *)adSize deviceType:(FanServerDeviceType)deviceType;
+ (void) setAppid:(NSString *)appId;
+ (void) setHideAdOnScrolling: (BOOL) scrolling;
+ (void) setWaitForImages: (BOOL) wait;
+ (void) setAge: (int) age;
+ (void) setGender: (FanServerAdGender) gender;
+ (void) allowGetLocation:(BOOL) choice;
+ (void) setServerAddress: (FanServerAddress) serverAddress;

+ (FanServer *)sharedInstance;

+ (void) requestAdData;

+ (void) preloadAds:(FanServerAdType)type size:(NSString *)size deviceType:(FanServerDeviceType) deviceType;

+ (void) showAd:(UIViewController*)adViewController x:(int)x y:(int)y adType:(FanServerAdType) type size:(NSString *)adSize deviceType:(FanServerDeviceType)deviceType orientation:(UIImageOrientation) orientation screenName: (NSString*) screenName;
+ (void) showBannerAd:(UIViewController*) adViewController size:(NSString *)adSize forView:(UIView *)view x:(int)x y:(int)y screenName: (NSString*) screenName;

@end
