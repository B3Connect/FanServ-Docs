package com.fanserv.test;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.widget.MediaController;
import android.widget.VideoView;

import com.fanserv.fanserver.AdVideoView;

public class TestVideo extends Activity {

	private VideoView videView;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		 setContentView(R.layout.test_video);
		 
		 videView = ((VideoView)findViewById(R.id.videoView1));
	
		 if (videView instanceof AdVideoView) ((AdVideoView)videView).setAdActive(true);
		 
		 videView.setVideoURI(Uri.parse("http://nba-dev.s3.amazonaws.com/videos/2012/10/26/cavity_flow_movie-1351246308.mp4"));
		 videView.requestFocus();						
		 videView.start();
		 
		 MediaController mediaController = new MediaController(this);
		 //mediaController.setAnchorView(videView);
		 videView.setMediaController(mediaController);
	}
	
	
}
