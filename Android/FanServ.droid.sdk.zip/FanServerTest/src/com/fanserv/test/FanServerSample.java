package com.fanserv.test;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.fanserv.fanserver.FanServer;
import com.fanserv.fanserver.FanServer.FanServerAdAnimation;
import com.fanserv.fanserver.FanServer.FanServerAddress;
import com.fanserv.fanserver.FanServer.FanServerAlign;

public class FanServerSample extends Activity {

	Spinner spinnerType, spinnerSize, spinnerAnimation, spinnerAnimationOut, spinnerPosition;
	
	String app_id = "cc9973936a3e432d868f29dc58d4bd15";
	String ad_type = "mobile-banner";
	
	String asset_type[] = {
			FanServer.FanServerAdTypePhoneBanner,
			FanServer.FanServerAdTypeTabletBanner,
			FanServer.FanServerAdTypePhonePopup,
			FanServer.FanServerAdTypePhoneInterstitial,
			FanServer.FanServerAdTypeTabletInterstitial
	};
	String banners_size_phone[] = {
			FanServer.FanServerAdSize300x50,
			FanServer.FanServerAdSize480x80,
			FanServer.FanServerAdSize600x100,
			FanServer.FanServerAdSize720x120,
			FanServer.FanServerAdSize1080x180
	};
	String banners_size_tablet[] = {	
			FanServer.FanServerAdSize728x90,
			FanServer.FanServerAdSize800x77,
			FanServer.FanServerAdSize1200x103,
			FanServer.FanServerAdSize1456x180,
			FanServer.FanServerAdSize1600x137
	};
	
	String popup_size[] = {
			FanServer.FanServerAdSize600x100,
		//	FanServer.FanServerAdSize600x300,
			FanServer.FanServerAdSize1080x180
		//	FanServer.FanServerAdSize1080x600
	};
	
	String interstitial_size_phone[] = {
			FanServer.FanServerAdSize300x250,
			FanServer.FanServerAdSize480x800,
			FanServer.FanServerAdSize600x500,
			FanServer.FanServerAdSize720x1200,
			FanServer.FanServerAdSize1080x1800
	};
	String interstitial_size_tablet[] = {			
			// tablet Interstitial
			FanServer.FanServerAdSize768x1024,
			FanServer.FanServerAdSize800x1280,
			FanServer.FanServerAdSize1200x1920,
			FanServer.FanServerAdSize1536x2048,
			FanServer.FanServerAdSize1600x2560,
	};
	
	
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_server_sample);
        spinnerType = (Spinner) findViewById(R.id.spinnerType);
        spinnerSize = (Spinner) findViewById(R.id.spinnerSize);
        spinnerAnimation = (Spinner) findViewById(R.id.spinnerAnimation);
        spinnerAnimationOut = (Spinner) findViewById(R.id.spinnerAnimationOut);
        spinnerPosition = (Spinner) findViewById(R.id.spinnerPosition);
        
        
        
        ad_type = FanServer.FanServerAdTypePhoneBanner; 
        
        
        {
			ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
					android.R.layout.simple_spinner_item, asset_type);
			adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spinnerType.setAdapter(adapter);
		}
		{
			ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
					android.R.layout.simple_spinner_item, banners_size_phone);
			adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spinnerSize.setAdapter(adapter);
		}
		{		
			String[] animation = new String[] {
			"Animation default", "Animation From Left", "Animation From Right", "Animation From Top", 
			"Animation From Bottom", "AnimationFade"};
			ArrayAdapter<String> animadapter = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, animation);
			animadapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spinnerAnimation.setAdapter(animadapter);
	    }{		
			String[] animation = new String[] {
			"Banner Animation default", "Banner Animation To Left", "Banner Animation To Right", 
			"Banner Animation To Top", "Banner Animation To Bottom", "Banner AnimationFade"};
			ArrayAdapter<String> animadapter = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, animation);
			animadapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spinnerAnimationOut.setAdapter(animadapter);
	    }
	    {		
			String[] animation = new String[] {
			"Banner Align Left", "Banner Align Center", "Banner Align Right",	 
			"Banner Align Top Left", "Banner Align Top Center", "Banner Align Top Right",
			"Random Position"};
			ArrayAdapter<String> animadapter = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, animation);
			animadapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spinnerPosition.setAdapter(animadapter);
	    }
	    
	    
	    IntentFilter intentFilter = new IntentFilter();
		intentFilter.addAction(FanServer.FanServerActionAdTapped);
		intentFilter.addAction(FanServer.FanServerActionBannerDidAppear);
		intentFilter.addAction(FanServer.FanServerActionBannerDidClose);
		intentFilter.addAction(FanServer.FanServerActionPopupDidAppear);
		intentFilter.addAction(FanServer.FanServerActionPopupDidClose);
		intentFilter.addAction(FanServer.FanServerActionInterstitialDidAppear);
		intentFilter.addAction(FanServer.FanServerActionInterstitialDidClose);
		
		intentFilter.addAction(FanServer.FanServerActionRequestDidFail);
		intentFilter.addAction(FanServer.FanServerActionAdDidFail);
		intentFilter.addAction(FanServer.FanServerActionDidBackFromAdView);
	    registerReceiver(mReceiver, intentFilter);
	    
	    
	    spinnerType.setOnItemSelectedListener(new OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> s, View v, int pos, long arg3) {
				ArrayAdapter<String> adapter = null;
				switch (pos) {
				case 0:	ad_type = FanServer.FanServerAdTypePhoneBanner; 
				adapter = new ArrayAdapter<String>(FanServerSample.this, 
						android.R.layout.simple_spinner_item, banners_size_phone);
				break;
				case 1:	ad_type = FanServer.FanServerAdTypeTabletBanner; 
				adapter = new ArrayAdapter<String>(FanServerSample.this, 
						android.R.layout.simple_spinner_item, banners_size_tablet);
				break;
				case 2:	ad_type = FanServer.FanServerAdTypePhonePopup; 
				adapter = new ArrayAdapter<String>(FanServerSample.this, 
						android.R.layout.simple_spinner_item, popup_size);
				break;
				case 3:	ad_type = FanServer.FanServerAdTypePhoneInterstitial; 
				adapter = new ArrayAdapter<String>(FanServerSample.this, 
						android.R.layout.simple_spinner_item, interstitial_size_phone);
				break;
				case 4:	ad_type = FanServer.FanServerAdTypeTabletInterstitial; 
				adapter = new ArrayAdapter<String>(FanServerSample.this, 
						android.R.layout.simple_spinner_item, interstitial_size_tablet);
				break;
				
				}
				adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
				spinnerSize.setAdapter(adapter);
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// 
				
			}
		});
    }
    
    public class MyBroadcastReceiver extends BroadcastReceiver {
		@Override
		public void onReceive(Context context, Intent intent) {
			Log.i(MyBroadcastReceiver.class.getSimpleName(),
					"received broadcast " + intent.getAction());
		}
	}
	 
	MyBroadcastReceiver mReceiver = new MyBroadcastReceiver();

	

	@Override
	protected void onDestroy() {
		super.onDestroy();
		unregisterReceiver(mReceiver);
	}
    
    
    public void buttonClick(View v) {
    	switch (v.getId()) {
    	
		case R.id.start:
			String ad_size = (String) spinnerSize.getAdapter().getItem(spinnerSize.getSelectedItemPosition());
			FanServer.getInstance().serverAddress(FanServerAddress.FanServerQa);
			FanServer.getInstance().init(app_id);
			
			switch (spinnerAnimation.getSelectedItemPosition()) {
			default : 
			case 0 : FanServer.getInstance().setAnimationStyle(FanServerAdAnimation.FanServerAdAnimationFromBottom); break;
			case 1 : FanServer.getInstance().setAnimationStyle(FanServerAdAnimation.FanServerAdAnimationFromLeft); break;
			case 2 : FanServer.getInstance().setAnimationStyle(FanServerAdAnimation.FanServerAdAnimationFromRight); break;
			case 3 : FanServer.getInstance().setAnimationStyle(FanServerAdAnimation.FanServerAdAnimationFromTop); break;
			case 4 : FanServer.getInstance().setAnimationStyle(FanServerAdAnimation.FanServerAdAnimationFromBottom); break;
			case 5 : FanServer.getInstance().setAnimationStyle(FanServerAdAnimation.FanServerAdAnimationFadeIn); break;
			}
			switch (spinnerAnimationOut.getSelectedItemPosition()) {
			default : 
			case 0 : FanServer.getInstance().setAnimationStyle(FanServerAdAnimation.FanServerAdAnimationToBottom); break;
			case 1 : FanServer.getInstance().setAnimationStyle(FanServerAdAnimation.FanServerAdAnimationToLeft); break;
			case 2 : FanServer.getInstance().setAnimationStyle(FanServerAdAnimation.FanServerAdAnimationToRight); break;
			case 3 : FanServer.getInstance().setAnimationStyle(FanServerAdAnimation.FanServerAdAnimationToTop); break;
			case 4 : FanServer.getInstance().setAnimationStyle(FanServerAdAnimation.FanServerAdAnimationToBottom); break;
			case 5 : FanServer.getInstance().setAnimationStyle(FanServerAdAnimation.FanServerAdAnimationFadeOut); break;
			}
			
			Intent intent = new Intent(this, TestWindow.class)
				.putExtra("ad_type", ad_type).putExtra("ad_size", ad_size);
	
			switch (spinnerPosition.getSelectedItemPosition()) {
			case 0 : FanServer.getInstance().setBannerAlign(FanServerAlign.FanServerAlignLeft); break;
			case 1 : FanServer.getInstance().setBannerAlign(FanServerAlign.FanServerAlignCenter); break;
			case 2 : FanServer.getInstance().setBannerAlign(FanServerAlign.FanServerAlignRight); break;
			case 3 : FanServer.getInstance().setBannerAlign(FanServerAlign.FanServerAlignTopLeft); break;
			case 4 : FanServer.getInstance().setBannerAlign(FanServerAlign.FanServerAlignTopCenter); break;
			case 5 : FanServer.getInstance().setBannerAlign(FanServerAlign.FanServerAlignTopRight); break;
			default : intent.putExtra("random", true);
			}
			
			startActivityForResult(intent, 1);
			break;
		default:
			break;
		}
    }

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == 1) FanServer.getInstance().sendLogs();
		super.onActivityResult(requestCode, resultCode, data);
	}
    
    
    
}
