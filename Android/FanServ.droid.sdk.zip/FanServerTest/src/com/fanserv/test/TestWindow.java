package com.fanserv.test;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.fanserv.fanserver.FanServer;
import com.fanserv.fanserver.FanServer.FanServerAlign;

public class TestWindow extends Activity {

	private static int id = 1;
	String ad_type = "", ad_size = "";
	boolean random;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.test_window);
		
		Bundle extras = getIntent().getExtras();
		if (extras != null && extras.containsKey("ad_type")) {
			ad_type = extras.getString("ad_type");
		} 
		if (extras != null && extras.containsKey("ad_size")) {
			ad_size = extras.getString("ad_size");
		} 
		random = extras != null && extras.containsKey("random");
		
	}
	
	@Override
	protected void onResume() {
		if (random) {
			double d = Math.random() * 6;
			if (d < 1) FanServer.getInstance().setBannerAlign(FanServerAlign.FanServerAlignTopLeft);
			else if (d < 2) FanServer.getInstance().setBannerAlign(FanServerAlign.FanServerAlignTopCenter);
			else if (d < 3) FanServer.getInstance().setBannerAlign(FanServerAlign.FanServerAlignTopRight);
			else if (d < 4) FanServer.getInstance().setBannerAlign(FanServerAlign.FanServerAlignLeft);
			else if (d < 5) FanServer.getInstance().setBannerAlign(FanServerAlign.FanServerAlignCenter);
			else  FanServer.getInstance().setBannerAlign(FanServerAlign.FanServerAlignRight);
			if (d - Math.floor(d) < 0.3) FanServer.getInstance().setBannerMargin(150);
			if (d - Math.floor(d) > 0.6) FanServer.getInstance().setBannerMargin(250);
		}
		
		FanServer.getInstance().startAd(this, ad_type, ad_size);
		super.onResume();
	}
	
	public void buttonClick(View v) {
		switch (v.getId()) {
		case R.id.buttonBack:	finish(); 	break;
		case R.id.buttonNext:	
			Intent i = new Intent(this, TestWindow.class).putExtra("ad_type", ad_type).putExtra("ad_size", ad_size);
			if (random) i.putExtra("random", true);
			startActivityForResult(i, ++id);
			break;
		case R.id.buttonVideo :
			startActivityForResult(new Intent(this, TestVideo.class).putExtra("ad_type", ad_type).putExtra("ad_size", ad_size), ++id);
			break;

		default:
			break;
		}
	}
}
